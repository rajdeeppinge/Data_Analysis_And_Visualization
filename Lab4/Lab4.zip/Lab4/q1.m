clear
close all

load('data_lab4.mat')

population = population_normal;

N= 10000;

sample_size= 1500;

jb_arr= zeros(N,1);

for i=1:N
    index= randperm(length(population),sample_size);
    sample = population( index );
    
    mu= mean(sample);
    sig= std(sample);
    
    skew= sum( ( (sample-mu)./sig).^3 ) /sample_size;
    kurtosis= sum( ( (sample-mu)./sig).^4 ) /sample_size;
   % calc the jb
   
    jb_arr(i)= sample_size/6*(skew*skew + (kurtosis-3)*(kurtosis-3)/4);
end

hist(jb_arr);