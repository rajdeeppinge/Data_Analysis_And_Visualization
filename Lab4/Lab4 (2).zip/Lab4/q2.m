clear;
close all;

load('data_lab4.mat');

ammonia = ammonia_concentration;
N = 60;

plot(ammonia)

%figure
%plot((1:1440), pdf('Normal', (1:1440), ammonia));

tpdf = pdf('Normal', (1:1440), ammonia);

figure
cdfplot(ammonia)

%figure
%plot(pdf(ammonia, (1:N)));

mu = mean(ammonia);
sigma = std(ammonia);

figure
plot((1:N), normpdf((1:N), mu, sigma));

figure
plot((1:N), normcdf((1:N), mu, sigma));

