clear
close all

load('data_lab4.mat')

%population = population_normal;
population= sample_50k;

mu= mean(population);
sig= std(population);
population= (population -mu)/sig; 
N= 10000;

sample_size= 50;

jb_arr= zeros(N,1);

for i=1:N
    
    permindex= randperm(length(population),sample_size);
    %shuffled_pop= population(permindex);
    sample = population(permindex);
    
    
    mu= mean(sample);
    sig= std(sample);
    
    skew= sum( ( (sample-mu)./sig).^3 ) /sample_size;
    kurtosis= sum( ( (sample-mu)./sig).^4 ) /sample_size;
   % calc the jb
   
   jb_arr(i)= sample_size/6*(skew*skew + (kurtosis-3)*(kurtosis-3)/4);
end

histogram(jb_arr);

figure
cdfplot(jb_arr)



sample_size= 1500;

jb_arr= zeros(N,1);

for i=1:N
    
    permindex= randperm(length(population),sample_size);
    %shuffled_pop= population(permindex);
    sample = population(permindex);
    
    
    mu= mean(sample);
    sig= std(sample);
    
    skew= sum( ( (sample-mu)./sig).^3 ) /sample_size;
    kurtosis= sum( ( (sample-mu)./sig).^4 ) /sample_size;
   % calc the jb
   
   jb_arr(i)= sample_size/6*(skew*skew + (kurtosis-3)*(kurtosis-3)/4);
end

figure
histogram(jb_arr);

figure
cdfplot(jb_arr)



sample_size= 2500;

jb_arr= zeros(N,1);

for i=1:N
    
    permindex= randperm(length(population),sample_size);
    %shuffled_pop= population(permindex);
    sample = population(permindex);
    
    %sample = randsample(population, sample_size);
    
    mu= mean(sample);
    sig= std(sample);
    
    skew= sum( ( (sample-mu)./sig).^3 ) /sample_size;
    kurtosis= sum( ( (sample-mu)./sig).^4 ) /sample_size;
   % calc the jb
   
   jb_arr(i)= sample_size/6*(skew*skew + (kurtosis-3)*(kurtosis-3)/4);
end

figure
histogram(jb_arr);

figure
cdfplot(jb_arr)